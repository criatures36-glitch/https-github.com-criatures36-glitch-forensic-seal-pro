
export interface ForensicData {
  fileName: string;
  fileSize: number;
  fileType: string;
  lastModified: number;
  hashSHA256: string;
  hashSHA512: string;
  timestamp: string;
  originalBuffer: ArrayBuffer;
  metadata?: Record<string, string>;
}

export enum AppStep {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  REVIEW = 'REVIEW',
  PROCESSING = 'PROCESSING',
  CERTIFIED = 'CERTIFIED',
}

export interface WalletState {
  address: string | null;
  isConnected: boolean;
  chainId: number | null;
}

export interface TradingReportData {
  uid: string;
  platform: string;
  periodStart: string;
  periodEnd: string;
  nFilledFailed: string;
  feesFilledFailed: string;
  pnlNoAbonado: string;
  nFailedFee: string;
  feesFailed: string;
  nRafagas: string;
  feesDobles: string;
  errors401: string;
  errorsSys: string;
  perdidasInducidas: string;
  totalDanos: string;
}
