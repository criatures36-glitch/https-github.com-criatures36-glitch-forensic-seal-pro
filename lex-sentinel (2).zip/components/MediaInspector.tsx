import React, { useState, useEffect, useRef } from 'react';
import { Eye, Layers, Zap, Activity, Image as ImageIcon, Music } from 'lucide-react';

interface MediaInspectorProps {
  file: File | null;
  buffer: ArrayBuffer | null;
  className?: string;
}

type FilterType = 'normal' | 'xray' | 'thermal' | 'edge';

const MediaInspector: React.FC<MediaInspectorProps> = ({ file, buffer, className }) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [filter, setFilter] = useState<FilterType>('normal');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (file && file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
      return () => URL.revokeObjectURL(url);
    } else {
      setPreviewUrl(null);
    }
  }, [file]);

  const getFilterStyle = () => {
    switch (filter) {
      case 'xray': return 'grayscale(100%) invert(100%) contrast(150%)';
      case 'thermal': return 'hue-rotate(180deg) saturate(300%) contrast(120%)';
      case 'edge': return 'grayscale(100%) contrast(200%) brightness(80%)'; // Simplified CSS simulation
      default: return 'none';
    }
  };

  const isImage = file?.type.startsWith('image/');
  const isAudio = file?.type.startsWith('audio/');

  return (
    <div className={`relative bg-black border border-gray-800 rounded overflow-hidden flex flex-col ${className}`}>
      
      {/* Toolbar */}
      <div className="flex items-center justify-between p-2 border-b border-gray-800 bg-black/50 backdrop-blur z-20">
        <div className="flex items-center gap-2 text-[10px] font-mono text-lexGold uppercase">
          <Activity className="w-3 h-3" />
          <span>Visual Interrogator</span>
        </div>
        
        {isImage && (
          <div className="flex gap-1">
             <button 
               onClick={() => setFilter('normal')}
               className={`px-2 py-1 text-[9px] border rounded ${filter === 'normal' ? 'bg-lexGold text-black border-lexGold' : 'text-gray-500 border-gray-700 hover:border-gray-500'}`}
             >
               RGB
             </button>
             <button 
               onClick={() => setFilter('xray')}
               className={`px-2 py-1 text-[9px] border rounded ${filter === 'xray' ? 'bg-lexGold text-black border-lexGold' : 'text-gray-500 border-gray-700 hover:border-gray-500'}`}
             >
               X-RAY
             </button>
             <button 
               onClick={() => setFilter('thermal')}
               className={`px-2 py-1 text-[9px] border rounded ${filter === 'thermal' ? 'bg-lexGold text-black border-lexGold' : 'text-gray-500 border-gray-700 hover:border-gray-500'}`}
             >
               HEAT
             </button>
          </div>
        )}
      </div>

      {/* Viewport */}
      <div className="flex-1 relative overflow-hidden flex items-center justify-center bg-[#080808] group">
        
        {/* Forensic Grid Overlay */}
        <div className="absolute inset-0 z-10 pointer-events-none opacity-20" 
             style={{ 
               backgroundImage: `linear-gradient(rgba(212, 175, 55, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(212, 175, 55, 0.1) 1px, transparent 1px)`,
               backgroundSize: '40px 40px'
             }}>
        </div>
        
        {/* Crosshair Center */}
        <div className="absolute inset-0 z-10 flex items-center justify-center pointer-events-none opacity-30">
            <div className="w-[1px] h-full bg-lexGold"></div>
            <div className="h-[1px] w-full bg-lexGold absolute"></div>
            <div className="w-20 h-20 border border-lexGold rounded-full absolute animate-pulse"></div>
        </div>

        {/* Content */}
        {previewUrl ? (
          <div className="relative w-full h-full flex items-center justify-center p-4">
             <img 
               src={previewUrl} 
               alt="Forensic Analysis" 
               className="max-w-full max-h-full object-contain transition-all duration-300"
               style={{ filter: getFilterStyle() }}
             />
             {filter === 'edge' && (
                // SVG Overlay to simulate edge detection more strongly than CSS can
                <div className="absolute inset-0 pointer-events-none mix-blend-difference bg-gray-500 opacity-50"></div>
             )}
          </div>
        ) : (
          <div className="text-center space-y-3 opacity-50">
             {isAudio ? <Music className="w-12 h-12 mx-auto text-gray-600" /> : <Layers className="w-12 h-12 mx-auto text-gray-600" />}
             <p className="font-mono text-xs text-gray-500 uppercase">
               {file ? 'Binary Visualization Unavailable' : 'No Signal Source'}
             </p>
             <p className="font-mono text-[9px] text-gray-700">
               {file ? `MIME: ${file.type.toUpperCase()}` : 'Awaiting Data Stream'}
             </p>
          </div>
        )}
        
        {/* Status Indicators */}
        <div className="absolute bottom-2 left-2 z-20 flex gap-2">
            <span className="text-[9px] font-mono bg-black/70 px-1 text-lexGreen border border-lexGreen/30">
                SIGNAL: {file ? 'LOCKED' : 'NO CARRIER'}
            </span>
        </div>
      </div>
    </div>
  );
};

export default MediaInspector;