
import React, { useState } from 'react';
import { X, FileText, Save, Calculator } from 'lucide-react';
import { TradingReportData } from '../types';
import Button from './Button';

interface ReportConfigModalProps {
  type: 'JUDICIAL' | 'SETTLEMENT';
  onClose: () => void;
  onSubmit: (data: TradingReportData) => void;
}

const ReportConfigModal: React.FC<ReportConfigModalProps> = ({ type, onClose, onSubmit }) => {
  const [formData, setFormData] = useState<TradingReportData>({
    uid: '',
    platform: 'ASTER DEX',
    periodStart: '2024-01-01',
    periodEnd: new Date().toISOString().split('T')[0],
    nFilledFailed: '0',
    feesFilledFailed: '0.00',
    pnlNoAbonado: '0.00',
    nFailedFee: '0',
    feesFailed: '0.00',
    nRafagas: '0',
    feesDobles: '0.00',
    errors401: '0',
    errorsSys: '0',
    perdidasInducidas: '0.00',
    totalDanos: '0.00',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const calculateTotal = () => {
    const total = (
        parseFloat(formData.feesFilledFailed) +
        parseFloat(formData.pnlNoAbonado) +
        parseFloat(formData.feesFailed) +
        parseFloat(formData.feesDobles) +
        parseFloat(formData.perdidasInducidas)
    ).toFixed(2);
    setFormData(prev => ({ ...prev, totalDanos: total }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    calculateTotal(); // Ensure calculation is fresh
    onSubmit(formData);
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-fade-in overflow-y-auto">
      <div className="w-full max-w-3xl bg-lexBlack border border-lexGold shadow-[0_0_50px_rgba(212,175,55,0.2)] flex flex-col my-8">
        
        {/* Header */}
        <div className="p-4 border-b border-lexGold/20 flex justify-between items-center bg-white/5">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-lexGold/10 rounded border border-lexGold/30">
               <FileText className="w-5 h-5 text-lexGold" />
            </div>
            <div>
               <h3 className="font-serif text-lg text-white tracking-widest text-glow">
                 {type === 'JUDICIAL' ? 'JUDICIAL AUDIT PARAMETERS' : 'SETTLEMENT AGREEMENT CONFIG'}
               </h3>
               <p className="font-mono text-[9px] text-lexGold uppercase">Input Verified Forensic Data</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded text-gray-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6 flex-1 overflow-y-auto custom-scrollbar bg-black/40">
            
            {/* Section 1: Case Info */}
            <div className="space-y-4">
                <h4 className="text-lexGold font-mono text-xs uppercase border-b border-gray-800 pb-2">Case Metadata</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">User UID</label>
                        <input name="uid" value={formData.uid} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" placeholder="e.g. 8839201" required />
                    </div>
                    <div>
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Platform Name</label>
                        <input name="platform" value={formData.platform} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" required />
                    </div>
                    <div>
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Period Start</label>
                        <input type="date" name="periodStart" value={formData.periodStart} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" />
                    </div>
                    <div>
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Period End</label>
                        <input type="date" name="periodEnd" value={formData.periodEnd} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" />
                    </div>
                </div>
            </div>

            {/* Section 2: Technical Findings */}
            <div className="space-y-4">
                <h4 className="text-lexGold font-mono text-xs uppercase border-b border-gray-800 pb-2">Technical Findings</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-white/5 p-4 rounded border border-white/5">
                    <div className="col-span-full text-[10px] text-gray-400 font-mono uppercase">Category 4.1: FILLED but FAILED</div>
                    <div>
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Count (N)</label>
                        <input type="number" name="nFilledFailed" value={formData.nFilledFailed} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" />
                    </div>
                    <div>
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Fees Charged (USDT)</label>
                        <input type="number" step="0.01" name="feesFilledFailed" value={formData.feesFilledFailed} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" />
                    </div>
                     <div>
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Missing PnL (USDT)</label>
                        <input type="number" step="0.01" name="pnlNoAbonado" value={formData.pnlNoAbonado} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" />
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-white/5 p-4 rounded border border-white/5">
                    <div className="col-span-full text-[10px] text-gray-400 font-mono uppercase">Category 4.2: FAILED with FEE</div>
                    <div>
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Count (N)</label>
                        <input type="number" name="nFailedFee" value={formData.nFailedFee} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" />
                    </div>
                    <div className="col-span-2">
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Fees Charged (USDT)</label>
                        <input type="number" step="0.01" name="feesFailed" value={formData.feesFailed} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" />
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-white/5 p-4 rounded border border-white/5">
                    <div className="col-span-full text-[10px] text-gray-400 font-mono uppercase">Category 4.3: Duplicate Charges</div>
                    <div>
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Bursts (N)</label>
                        <input type="number" name="nRafagas" value={formData.nRafagas} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" />
                    </div>
                    <div className="col-span-2">
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Excess Fees (USDT)</label>
                        <input type="number" step="0.01" name="feesDobles" value={formData.feesDobles} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" />
                    </div>
                </div>
            </div>

            {/* Section 3: Totals */}
            <div className="space-y-4">
                <h4 className="text-lexGold font-mono text-xs uppercase border-b border-gray-800 pb-2">Damage Quantification</h4>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-[10px] font-mono text-gray-500 mb-1">Induced Losses (Execution Failure)</label>
                        <input type="number" step="0.01" name="perdidasInducidas" value={formData.perdidasInducidas} onChange={handleChange} className="w-full bg-black border border-gray-700 p-2 text-xs font-mono text-white focus:border-lexGold outline-none" />
                    </div>
                    <div>
                        <div className="flex items-center justify-between mb-1">
                            <label className="block text-[10px] font-mono text-lexRed font-bold">TOTAL CLAIM AMOUNT (USDT)</label>
                            <button type="button" onClick={calculateTotal} className="text-[9px] text-lexGold hover:underline flex items-center gap-1"><Calculator className="w-3 h-3"/> Recalculate</button>
                        </div>
                        <input type="number" step="0.01" name="totalDanos" value={formData.totalDanos} readOnly className="w-full bg-lexRed/10 border border-lexRed p-2 text-xs font-mono text-lexRed font-bold outline-none cursor-not-allowed" />
                    </div>
                 </div>
            </div>

        </form>

        <div className="p-4 border-t border-lexGold/20 bg-black flex justify-end gap-4">
            <Button variant="secondary" onClick={onClose} className="text-xs">Cancel</Button>
            <Button onClick={handleSubmit} className="text-xs px-8">
                <Save className="w-4 h-4 mr-2 inline" /> GENERATE REPORT
            </Button>
        </div>
      </div>
    </div>
  );
};

export default ReportConfigModal;
