import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { X, QrCode, Copy, ExternalLink, Check } from 'lucide-react';

interface QRCodeModalProps {
  hash: string;
  onClose: () => void;
}

const QRCodeModal: React.FC<QRCodeModalProps> = ({ hash, onClose }) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  
  const verificationUrl = `https://lex-sentinel.io/verify/${hash}`;

  useEffect(() => {
    const generate = async () => {
      try {
        const url = await QRCode.toDataURL(verificationUrl, {
          width: 300,
          margin: 1,
          color: {
            dark: '#D4AF37', // Gold
            light: '#000000', // Black
          }
        });
        setQrDataUrl(url);
      } catch (err) {
        console.error(err);
      }
    };
    generate();
  }, [verificationUrl]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(verificationUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-fade-in">
       <div className="w-full max-w-md bg-lexBlack border border-lexGold shadow-[0_0_50px_rgba(212,175,55,0.2)] relative overflow-hidden flex flex-col items-center p-8">
          {/* Close Button */}
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Header */}
          <div className="text-center mb-6">
            <QrCode className="w-12 h-12 text-lexGold mx-auto mb-2 animate-pulse" />
            <h3 className="font-serif text-2xl text-white tracking-widest text-glow">VERIFICATION MATRIX</h3>
            <p className="font-mono text-[10px] text-lexGold uppercase tracking-[0.2em]">Scan to Validate Evidence Integrity</p>
          </div>

          {/* QR Code Container */}
          <div className="relative p-2 border-2 border-dashed border-lexGold/30 rounded mb-6 group">
             <div className="absolute inset-0 bg-lexGold/5 animate-pulse"></div>
             {qrDataUrl ? (
                <img src={qrDataUrl} alt="Verification QR" className="w-64 h-64 object-contain shadow-2xl relative z-10" />
             ) : (
                <div className="w-64 h-64 flex items-center justify-center text-lexGold/50 font-mono text-xs">Generating Matrix...</div>
             )}
             
             {/* Corner Accents */}
             <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-lexGold"></div>
             <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-lexGold"></div>
             <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-lexGold"></div>
             <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-lexGold"></div>
          </div>

          {/* URL Box */}
          <div className="w-full bg-black/50 border border-gray-800 rounded p-3 flex items-center gap-3 mb-2">
             <div className="flex-1 overflow-hidden">
                <p className="text-[9px] text-gray-500 font-mono uppercase mb-1">Secure Link</p>
                <p className="text-xs text-lexGold font-mono truncate">{verificationUrl}</p>
             </div>
             <button onClick={copyToClipboard} className="p-2 hover:bg-lexGold/10 rounded text-gray-400 hover:text-white transition-colors" title="Copy Link">
                {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
             </button>
             <a href={verificationUrl} target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-lexGold/10 rounded text-gray-400 hover:text-white transition-colors" title="Open Link">
                <ExternalLink className="w-4 h-4" />
             </a>
          </div>
          
          <div className="text-[9px] text-gray-600 font-mono text-center">
             ID: {hash.substring(0, 16)}...
          </div>
       </div>
    </div>
  );
};

export default QRCodeModal;