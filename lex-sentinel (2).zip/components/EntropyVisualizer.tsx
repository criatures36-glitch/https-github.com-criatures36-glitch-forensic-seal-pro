
import React, { useEffect, useRef } from 'react';

interface EntropyVisualizerProps {
  buffer: ArrayBuffer | null;
  className?: string;
}

const EntropyVisualizer: React.FC<EntropyVisualizerProps> = ({ buffer, className }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!buffer || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas for high DPI
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    // 1. Calculate Byte Frequency (Histogram)
    // We analyze the first 10KB to keep performance high
    const view = new Uint8Array(buffer.slice(0, 10240)); 
    const frequencies = new Array(256).fill(0);
    let maxFreq = 0;

    for (let i = 0; i < view.length; i++) {
      frequencies[view[i]]++;
      if (frequencies[view[i]] > maxFreq) maxFreq = frequencies[view[i]];
    }

    // 2. Draw Visualization
    ctx.clearRect(0, 0, width, height);
    
    // Grid Lines
    ctx.strokeStyle = 'rgba(0, 255, 65, 0.1)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i < width; i+=20) { ctx.moveTo(i, 0); ctx.lineTo(i, height); }
    for (let i = 0; i < height; i+=20) { ctx.moveTo(0, i); ctx.lineTo(width, i); }
    ctx.stroke();

    // Bar Chart
    const barWidth = width / 256;
    
    ctx.fillStyle = 'rgba(212, 175, 55, 0.8)'; // Gold
    
    for (let i = 0; i < 256; i++) {
      const freq = frequencies[i];
      const barHeight = (freq / maxFreq) * (height * 0.8);
      const x = i * barWidth;
      const y = height - barHeight;

      // Color variation based on intensity
      const intensity = freq / maxFreq;
      ctx.fillStyle = `rgba(${212}, ${175 + (intensity * 50)}, 55, ${0.4 + intensity * 0.6})`;

      ctx.fillRect(x, y, barWidth + 0.5, barHeight);
    }

    // Overlay Line
    ctx.strokeStyle = '#D4AF37';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, height - (frequencies[0] / maxFreq) * (height * 0.8));
    for (let i = 1; i < 256; i++) {
         const freq = frequencies[i];
         const y = height - (freq / maxFreq) * (height * 0.8);
         // Smooth curve approximation
         ctx.lineTo(i * barWidth, y);
    }
    ctx.stroke();

  }, [buffer]);

  return (
    <div className={`relative bg-black border border-gray-800 rounded overflow-hidden ${className}`}>
      <canvas ref={canvasRef} className="w-full h-full" style={{ width: '100%', height: '100%' }} />
      <div className="absolute top-2 left-2 text-[9px] font-mono text-lexGold uppercase tracking-widest bg-black/50 px-2 rounded backdrop-blur-sm border border-lexGold/20">
        Entropy / Byte Distribution
      </div>
      <div className="absolute bottom-1 right-2 text-[8px] font-mono text-gray-500">
        0x00 - 0xFF
      </div>
    </div>
  );
};

export default EntropyVisualizer;
