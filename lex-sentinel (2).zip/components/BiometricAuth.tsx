import React from 'react';
import { Fingerprint, Scan } from 'lucide-react';

const BiometricAuth: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/95 backdrop-blur-md cursor-wait">
      <div className="relative flex flex-col items-center">
        
        {/* Scanner Ring */}
        <div className="relative w-64 h-64 border border-lexRed/30 rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(255,0,0,0.2)]">
           <div className="absolute inset-0 border-t-2 border-lexRed animate-spin duration-[3000ms]"></div>
           <div className="absolute inset-2 border-b-2 border-lexGold/50 rounded-full animate-spin duration-[2000ms] direction-reverse"></div>
           
           {/* Scanning Beam */}
           <div className="absolute inset-0 bg-gradient-to-b from-transparent via-lexRed/20 to-transparent animate-scan-down rounded-full overflow-hidden"></div>

           {/* Icon */}
           <div className="relative z-10 p-8 bg-black/50 rounded-full border border-lexRed/50">
             <Fingerprint className="w-16 h-16 text-lexRed animate-pulse" />
           </div>
        </div>

        {/* Text Details */}
        <div className="mt-8 text-center space-y-2">
           <div className="text-lexRed font-mono text-sm tracking-[0.3em] animate-pulse">BIOMETRIC AUTHENTICATION REQUIRED</div>
           <h2 className="text-3xl font-serif text-white tracking-widest text-glow">VERIFYING OFFICER</h2>
           <div className="flex items-center justify-center gap-2 text-lexGold/70 font-mono text-xs mt-4">
              <Scan className="w-4 h-4 animate-spin" />
              <span>MATCHING BIOMETRIC HASH...</span>
           </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-1/2 -left-32 w-24 h-[1px] bg-lexRed/30"></div>
        <div className="absolute top-1/2 -right-32 w-24 h-[1px] bg-lexRed/30"></div>
      </div>
    </div>
  );
};

export default BiometricAuth;