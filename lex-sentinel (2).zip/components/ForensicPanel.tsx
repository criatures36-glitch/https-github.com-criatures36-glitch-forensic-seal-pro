import React, { useState } from 'react';
import { Binary, Eye, Activity, FileJson, Cpu } from 'lucide-react';
import HexViewer from './HexViewer';
import EntropyVisualizer from './EntropyVisualizer';
import MediaInspector from './MediaInspector';
import { ForensicData } from '../types';

interface ForensicPanelProps {
  data: ForensicData | null;
  onShowMetadata: () => void;
}

type TabMode = 'VISUAL' | 'HEX' | 'ENTROPY';

const ForensicPanel: React.FC<ForensicPanelProps> = ({ data, onShowMetadata }) => {
  const [mode, setMode] = useState<TabMode>('VISUAL');

  return (
    <div className="bg-black/80 border border-gray-800 rounded p-1 relative overflow-hidden backdrop-blur-md flex flex-col h-[600px]">
      
      {/* Cyberdeck Header / Tabs */}
      <div className="flex items-center gap-1 p-1 mb-1 bg-black/40 border-b border-gray-800">
        <div className="mr-4 pl-2 opacity-50">
            <Cpu className="w-5 h-5 text-gray-500" />
        </div>
        
        <button 
          onClick={() => setMode('VISUAL')}
          className={`flex items-center gap-2 px-4 py-2 text-[10px] font-mono uppercase tracking-wider border-t-2 transition-all ${mode === 'VISUAL' ? 'border-lexGold bg-lexGold/10 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
        >
          <Eye className="w-3 h-3" /> Visual
        </button>

        <button 
          onClick={() => setMode('HEX')}
          className={`flex items-center gap-2 px-4 py-2 text-[10px] font-mono uppercase tracking-wider border-t-2 transition-all ${mode === 'HEX' ? 'border-lexGold bg-lexGold/10 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
        >
          <Binary className="w-3 h-3" /> Hex Matrix
        </button>

        <button 
          onClick={() => setMode('ENTROPY')}
          className={`flex items-center gap-2 px-4 py-2 text-[10px] font-mono uppercase tracking-wider border-t-2 transition-all ${mode === 'ENTROPY' ? 'border-lexGold bg-lexGold/10 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
        >
          <Activity className="w-3 h-3" /> Entropy
        </button>

        <div className="flex-1"></div>

        <button 
           onClick={onShowMetadata}
           className="flex items-center gap-2 px-3 py-1 bg-lexGold/5 border border-lexGold/20 hover:bg-lexGold/20 text-lexGold text-[9px] font-mono uppercase mr-1 transition-colors"
        >
           <FileJson className="w-3 h-3" /> Meta-Tags
        </button>
      </div>

      {/* Main Viewport */}
      <div className="flex-1 relative bg-black/50 p-1 overflow-hidden">
         {/* CRT Scanline Overlay applied to the viewport */}
         <div className="absolute inset-0 bg-repeat-y z-30 pointer-events-none opacity-5" style={{ backgroundImage: 'linear-gradient(rgba(0,0,0,0) 50%, rgba(0,0,0,0.25) 50%), linear-gradient(90deg, rgba(255,0,0,0.06), rgba(0,255,0,0.02), rgba(0,0,255,0.06))', backgroundSize: '100% 2px, 3px 100%' }}></div>
         
         {mode === 'VISUAL' && (
             <MediaInspector 
                file={data ? new File([data.originalBuffer], data.fileName, { type: data.fileType }) : null} 
                buffer={data?.originalBuffer || null}
                className="w-full h-full"
             />
         )}
         {mode === 'HEX' && (
             <HexViewer buffer={data?.originalBuffer || null} className="w-full h-full" />
         )}
         {mode === 'ENTROPY' && (
             <EntropyVisualizer buffer={data?.originalBuffer || null} className="w-full h-full" />
         )}
      </div>

      {/* Footer Info Strip */}
      <div className="h-8 border-t border-gray-800 bg-black flex items-center justify-between px-3 text-[9px] font-mono text-gray-600">
         <div className="flex gap-4">
             <span>SHA-256: {data ? data.hashSHA256.substring(0, 16) + '...' : 'N/A'}</span>
             <span>SIZE: {data ? (data.fileSize / 1024).toFixed(2) + ' KB' : '0 KB'}</span>
         </div>
         <div className="text-lexGold/50 animate-pulse">
            {data ? 'TARGET ACQUIRED' : 'SYSTEM IDLE'}
         </div>
      </div>

    </div>
  );
};

export default ForensicPanel;