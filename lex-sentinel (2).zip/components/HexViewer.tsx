import React, { useEffect, useState } from 'react';

interface HexViewerProps {
  buffer: ArrayBuffer | null;
  className?: string;
}

const HexViewer: React.FC<HexViewerProps> = ({ buffer, className }) => {
  const [hexLines, setHexLines] = useState<string[]>([]);
  
  useEffect(() => {
    if (!buffer) return;
    
    // Create a view of the buffer, limit to first 1024 bytes to prevent lag
    const view = new Uint8Array(buffer.slice(0, 512));
    const lines = [];
    let currentLine = '';
    let asciiLine = '';
    
    for (let i = 0; i < view.length; i++) {
      const hex = view[i].toString(16).padStart(2, '0').toUpperCase();
      const charCode = view[i];
      const char = (charCode >= 32 && charCode <= 126) ? String.fromCharCode(charCode) : '.';
      
      currentLine += hex + ' ';
      asciiLine += char;

      // Break every 16 bytes
      if ((i + 1) % 16 === 0) {
        lines.push({ offset: (i - 15).toString(16).padStart(8, '0').toUpperCase(), hex: currentLine, ascii: asciiLine });
        currentLine = '';
        asciiLine = '';
      }
    }
    setHexLines(lines.map(l => `${l.offset}  ${l.hex.padEnd(48, ' ')}  |${l.ascii}|`));
  }, [buffer]);

  if (!buffer) return null;

  return (
    <div className={`font-mono text-[10px] leading-3 text-lexGreen/80 h-full overflow-hidden relative bg-black p-3 border border-lexGreen/30 rounded ${className}`}>
      {/* Overlay Gradient for CRT effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-lexGreen/5 to-transparent pointer-events-none z-10"></div>
      
      <div className="overflow-y-auto h-full custom-scrollbar pr-2">
        {hexLines.map((line, i) => (
          <div key={i} className="whitespace-pre hover:bg-lexGreen/10 transition-colors duration-150">
            {line}
          </div>
        ))}
        {hexLines.length === 0 && <div className="animate-pulse">AWAITING INPUT STREAM...</div>}
      </div>
      
      <div className="absolute top-2 right-2 text-lexGreen text-[9px] animate-pulse">LIVE HEXDUMP</div>
    </div>
  );
};

export default HexViewer;