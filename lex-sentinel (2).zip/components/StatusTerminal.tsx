import React, { useRef, useEffect } from 'react';
import { AppStep } from '../types';

interface Log {
  id: number;
  text: string;
  type: 'info' | 'success' | 'warning' | 'error';
}

interface StatusTerminalProps {
  logs: Log[];
  step: AppStep;
  isWalletConnected: boolean;
}

const StatusTerminal: React.FC<StatusTerminalProps> = ({ logs, step, isWalletConnected }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const getSuggestions = () => {
    switch (step) {
      case AppStep.IDLE:
        return [
           { cmd: './mount_evidence', desc: 'Select File' },
           { cmd: 'sys_diagnostics', desc: 'Check Integrity' }
        ];
      case AppStep.ANALYZING:
         return [
            { cmd: 'monitor -v', desc: 'Live Stream' },
            { cmd: 'top', desc: 'Process Monitor' }
         ];
      case AppStep.REVIEW:
        const cmds = [
            { cmd: 'exec seal_protocol', desc: 'Certify Evidence' },
            { cmd: 'cat metadata.json', desc: 'View Metadata' }
        ];
        if (!isWalletConnected) {
            cmds.unshift({ cmd: 'net_connect', desc: 'Link Wallet' });
        }
        return cmds;
      case AppStep.PROCESSING:
        return [{ cmd: 'await_confirmation', desc: 'Processing...' }];
      case AppStep.CERTIFIED:
        return [
           { cmd: 'mint_token', desc: 'Anchor to Blockchain' },
           { cmd: 'wget report.pdf', desc: 'Download Audit' },
           { cmd: 'reboot', desc: 'New Session' }
        ];
      default:
        return [];
    }
  };

  return (
    <div className="w-full bg-black border border-gray-800 rounded-lg p-4 font-mono text-xs h-64 overflow-hidden relative shadow-[inset_0_0_20px_rgba(0,0,0,0.8)] group flex flex-col">
      
      {/* CRT Scanline Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-10 pointer-events-none bg-[length:100%_4px,6px_100%] opacity-20"></div>

      {/* Header */}
      <div className="shrink-0 bg-black/90 backdrop-blur pb-2 mb-2 border-b border-gray-800 flex justify-between items-center z-20">
        <span className="text-gray-500 uppercase tracking-widest flex items-center gap-2">
            <span className="w-2 h-2 bg-lexGreen rounded-full animate-pulse"></span>
            :: SYSTEM KERNEL ::
        </span>
        <div className="text-[10px] text-gray-600">TTY-S01</div>
      </div>
      
      {/* Logs Area */}
      <div className="flex-1 flex flex-col gap-1 relative z-10 overflow-y-auto custom-scrollbar min-h-0">
        {logs.map((log) => (
          <div key={log.id} className={`${
            log.type === 'error' ? 'text-red-500 text-glow' : 
            log.type === 'success' ? 'text-lexGreen text-glow' : 
            log.type === 'warning' ? 'text-lexGold' : 'text-gray-400'
          } flex gap-2 shrink-0`}>
            <span className="opacity-30 select-none">root@lex:~#</span>
            <span className="typing-effect">{log.text}</span>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Command Prompt / Suggestions Footer */}
      <div className="shrink-0 mt-2 pt-2 border-t border-gray-800/50 relative z-20 bg-black/40">
        <div className="flex items-center gap-2 text-lexGreen mb-1">
           <span className="opacity-50">root@lex:~#</span>
           <span className="animate-pulse w-2 h-4 bg-lexGreen block"></span>
        </div>
        <div className="flex flex-wrap gap-x-4 gap-y-1 pl-4">
           {getSuggestions().map((s, i) => (
              <div key={i} className="group flex items-center gap-1 cursor-default opacity-60 hover:opacity-100 transition-opacity">
                  <span className="text-gray-600 font-bold">{'>'}</span>
                  <span className="text-lexGold/80 group-hover:text-lexGold transition-colors">{s.cmd}</span>
                  <span className="text-gray-600 text-[9px] uppercase">[{s.desc}]</span>
              </div>
           ))}
        </div>
      </div>
    </div>
  );
};

export default StatusTerminal;