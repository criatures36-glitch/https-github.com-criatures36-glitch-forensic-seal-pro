import React from 'react';
import { Wallet, ShieldAlert, Activity, Globe, Lock, WifiOff, Sun, Moon } from 'lucide-react';
import Button from './Button';
import { WalletState } from '../types';

interface HeaderProps {
  wallet: WalletState;
  onConnect: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const getNetworkName = (chainId: number | null) => {
  if (!chainId) return "UNKNOWN NET";
  // Common Chain IDs
  switch (chainId) {
    case 1: return "ETH MAINNET";
    case 11155111: return "SEPOLIA";
    case 5: return "GOERLI";
    case 137: return "POLYGON";
    case 80001: return "MUMBAI";
    case 80002: return "AMOY";
    case 56: return "BSC";
    default: return `CHAIN ID: ${chainId}`;
  }
};

const Header: React.FC<HeaderProps> = ({ wallet, onConnect, isDarkMode, toggleTheme }) => {
  return (
    <header className="fixed top-0 w-full z-50 border-b border-gray-200 dark:border-white/10 bg-white/90 dark:bg-lexBlack/90 backdrop-blur-md shadow-sm dark:shadow-2xl transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 h-24 flex items-center justify-between">
        
        {/* Logo Section */}
        <div className="flex items-center gap-4 group cursor-default select-none">
          <div className="relative">
            <ShieldAlert className="w-10 h-10 text-lexGold transition-transform group-hover:scale-105 duration-500" />
            <div className="absolute inset-0 bg-lexGold blur-xl opacity-20 group-hover:opacity-40 transition-opacity duration-500"></div>
          </div>
          <div className="flex flex-col">
            <h1 className="font-serif text-3xl text-gray-900 dark:text-white tracking-widest leading-none transition-colors duration-300">
              LEX <span className="text-lexGold">SENTINEL</span>
            </h1>
            <div className="flex items-center gap-2 mt-1">
              <div className="h-[1px] w-8 bg-lexRed"></div>
              <p className="font-mono text-[9px] text-gray-500 tracking-[0.3em] uppercase">
                Forensic Certification Unit
              </p>
            </div>
          </div>
        </div>

        {/* Status & Action Section */}
        <div className="flex items-center gap-6">
          
          {/* Theme Toggle */}
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-white/10 text-gray-600 dark:text-gray-400 transition-all duration-300"
            title="Toggle Theme"
          >
            {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>

          {/* Telemetry Display - Only visible on larger screens */}
          <div className="hidden md:flex flex-col items-end gap-1 text-right border-r border-gray-200 dark:border-white/10 pr-6 mr-2 transition-colors duration-300">
             <div className="flex items-center gap-2">
                <span className={`text-[10px] font-mono tracking-widest uppercase transition-colors duration-300 ${wallet.isConnected ? 'text-green-600 dark:text-green-500 drop-shadow-sm dark:drop-shadow-[0_0_5px_rgba(34,197,94,0.5)]' : 'text-lexRed drop-shadow-sm dark:drop-shadow-[0_0_5px_rgba(239,68,68,0.5)]'}`}>
                    {wallet.isConnected ? 'UPLINK SECURE' : 'UPLINK OFFLINE'}
                </span>
                <div className={`w-2 h-2 rounded-full transition-all duration-300 ${wallet.isConnected ? 'bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.8)]' : 'bg-lexRed shadow-[0_0_8px_rgba(239,68,68,0.8)]'}`}></div>
             </div>
             
             {wallet.isConnected ? (
                <div className="flex items-center gap-3 text-[10px] font-mono text-lexGold animate-fade-in">
                    <span className="flex items-center gap-1 opacity-80"><Globe className="w-3 h-3" /> {getNetworkName(wallet.chainId)}</span>
                    <span className="text-gray-400 dark:text-gray-700">|</span>
                    <span className="flex items-center gap-1 opacity-80"><Activity className="w-3 h-3" /> 24ms</span>
                </div>
             ) : (
                <span className="text-[10px] font-mono text-gray-400 dark:text-gray-600 uppercase">Waiting for signature...</span>
             )}
          </div>

          {/* Connect Button Area */}
          <Button 
            onClick={onConnect} 
            variant={wallet.isConnected ? "primary" : "secondary"} 
            className={`min-w-[200px] border-l-4 transition-all duration-300 ${wallet.isConnected ? 'border-l-green-500' : 'border-l-lexRed hover:border-l-red-400'}`}
          >
             <div className="flex items-center justify-between w-full gap-4">
               <div className={`p-1.5 rounded bg-gray-100 dark:bg-black/40 backdrop-blur-sm border border-gray-200 dark:border-white/5 ${wallet.isConnected ? 'text-green-600 dark:text-green-400' : 'text-gray-500 dark:text-gray-400'}`}>
                 {wallet.isConnected ? <Lock className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
               </div>
               
               <div className="flex flex-col items-start flex-1">
                  <span className={`text-[9px] font-bold uppercase leading-none mb-1 transition-colors ${wallet.isConnected ? 'text-green-600/70 dark:text-green-500/70' : 'text-lexRed/70'}`}>
                    {wallet.isConnected ? 'WALLET IDENTITY' : 'CONNECTION STATUS'}
                  </span>
                  <span className="text-xs font-mono tracking-wider text-gray-800 dark:text-white">
                    {wallet.isConnected && wallet.address 
                      ? `${wallet.address.slice(0, 6)}...${wallet.address.slice(-4)}`
                      : "CONNECT WALLET"}
                  </span>
               </div>
             </div>
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;