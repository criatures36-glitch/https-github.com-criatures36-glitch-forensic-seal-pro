
import { PDFDocument, StandardFonts, rgb, degrees } from 'pdf-lib';

const LEX_BLACK = rgb(0.02, 0.02, 0.02);
const LEX_GOLD = rgb(0.83, 0.68, 0.21); // #D4AF37

/**
 * Generates a detailed Technical Whitepaper explaining the forensic methodology.
 */
export const generateWhitePaper = async (fileName: string, hash: string): Promise<Uint8Array> => {
  const pdfDoc = await PDFDocument.create();
  
  // Fonts
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontMono = await pdfDoc.embedFont(StandardFonts.Courier);

  // --- PAGE 1: COVER ---
  const coverPage = pdfDoc.addPage([595.28, 841.89]);
  const { width, height } = coverPage.getSize();

  // Background Element
  coverPage.drawRectangle({ x: 0, y: 0, width: 40, height: height, color: LEX_BLACK });
  coverPage.drawRectangle({ x: 40, y: height - 150, width: width - 40, height: 150, color: LEX_BLACK });

  // Title
  coverPage.drawText('LEX SENTINEL', {
    x: 60,
    y: height - 80,
    size: 40,
    font: fontBold,
    color: LEX_GOLD,
  });

  coverPage.drawText('TECHNICAL WHITE PAPER', {
    x: 60,
    y: height - 110,
    size: 14,
    font: fontMono,
    color: rgb(1, 1, 1),
    opacity: 0.8
  });

  coverPage.drawText('FORENSIC ARCHITECTURE & METHODOLOGY', {
    x: 60,
    y: height - 130,
    size: 10,
    font: fontRegular,
    color: rgb(0.8, 0.8, 0.8),
  });

  // Target Details
  let y = height / 2 + 50;
  coverPage.drawText('TARGET EVIDENCE ANALYSIS', { x: 60, y, size: 12, font: fontBold, color: LEX_BLACK });
  y -= 20;
  coverPage.drawText(`FILE: ${fileName}`, { x: 60, y, size: 10, font: fontMono, color: rgb(0.3, 0.3, 0.3) });
  y -= 15;
  coverPage.drawText(`HASH (SHA-256): ${hash.substring(0, 40)}...`, { x: 60, y, size: 10, font: fontMono, color: rgb(0.3, 0.3, 0.3) });

  // Abstract
  y -= 80;
  const abstract = [
    "This document outlines the technical specifications, cryptographic protocols,",
    "and blockchain consensus mechanisms utilized by the Lex Sentinel platform",
    "to ensure the integrity, authenticity, and non-repudiation of digital evidence.",
    "The methodology complies with ISO/IEC 27037 guidelines for digital forensics."
  ];

  abstract.forEach((line, i) => {
    coverPage.drawText(line, { x: 60, y: y - (i * 15), size: 10, font: fontRegular, color: rgb(0.4, 0.4, 0.4) });
  });

  // Footer
  coverPage.drawText('CLASSIFIED // INTERNAL USE ONLY', {
    x: width / 2 - 80,
    y: 30,
    size: 8,
    font: fontMono,
    color: rgb(0.6, 0.6, 0.6),
  });


  // --- PAGE 2: ARCHITECTURE ---
  const p2 = pdfDoc.addPage([595.28, 841.89]);
  y = height - 60;

  const drawHeader = (page: any, text: string) => {
    page.drawText(text, { x: 50, y, size: 16, font: fontBold, color: LEX_BLACK });
    page.drawLine({ start: { x: 50, y: y - 10 }, end: { x: width - 50, y: y - 10 }, thickness: 2, color: LEX_GOLD });
    y -= 40;
  };

  const drawParagraph = (page: any, lines: string[]) => {
    lines.forEach(line => {
      page.drawText(line, { x: 50, y, size: 10, font: fontRegular, color: rgb(0.2, 0.2, 0.2) });
      y -= 14;
    });
    y -= 20;
  };

  drawHeader(p2, '1. CRYPTOGRAPHIC HASHING ENGINE');
  
  drawParagraph(p2, [
    "Lex Sentinel employs a client-side hashing mechanism utilizing the Web Crypto API.",
    "This ensures that the original file payload never leaves the user's local device,",
    "guaranteeing absolute privacy and GDPR compliance. The file is processed in chunks",
    "to generate a deterministic fingerprint using the SHA-256 and SHA-512 algorithms."
  ]);

  p2.drawText('ALGORITHM SPECIFICATIONS:', { x: 50, y, size: 10, font: fontBold });
  y -= 20;
  p2.drawText('• SHA-256 (NIST FIPS 180-4): 256-bit digest, collision resistant.', { x: 60, y, size: 9, font: fontMono });
  y -= 15;
  p2.drawText('• SHA-512 (High Security): 512-bit digest, immune to length extension attacks.', { x: 60, y, size: 9, font: fontMono });
  y -= 40;

  drawHeader(p2, '2. BLOCKCHAIN IMMUTABILITY');
  
  drawParagraph(p2, [
    "To establish a 'Proof of Existence', the generated hash is anchored to a public",
    "decentralized ledger (EVM Compatible Blockchain). This process involves creating",
    "a self-transaction where the hash is encoded into the 'Input Data' field (0x...)",
    "of the transaction payload. This entry is immutable, timestamped by the network",
    "validators, and replicated across thousands of nodes worldwide."
  ]);

  // --- PAGE 3: LEGAL COMPLIANCE ---
  const p3 = pdfDoc.addPage([595.28, 841.89]);
  y = height - 60;

  drawHeader(p3, '3. REGULATORY COMPLIANCE');

  drawParagraph(p3, [
    "The architecture allows users to demonstrate compliance with international standards",
    "regarding electronic signatures and data integrity."
  ]);

  y -= 10;
  p3.drawText('eIDAS (EU Regulation 910/2014):', { x: 50, y, size: 11, font: fontBold });
  y -= 20;
  drawParagraph(p3, [
    "While Lex Sentinel provides 'Advanced Electronic Seals', the blockchain anchoring",
    "serves as a qualified timestamping equivalent under Article 42, proving that data",
    "existed at a specific time and has not been altered."
  ]);

  p3.drawText('ESIGN Act (USA) & UETA:', { x: 50, y, size: 11, font: fontBold });
  y -= 20;
  drawParagraph(p3, [
    "The electronic records generated are admissible in court as evidence of integrity,",
    "satisfying requirements for electronic retention of records."
  ]);

  // QR Code Placeholder visual
  y -= 40;
  p3.drawRectangle({
      x: width/2 - 50,
      y: y - 100,
      width: 100,
      height: 100,
      borderColor: LEX_BLACK,
      borderWidth: 1
  });
  p3.drawText('VERIFICATION ANCHOR', { x: width/2 - 55, y: y - 115, size: 8, font: fontMono });
  p3.drawText('https://lex-sentinel.io', { x: width/2 - 50, y: y - 125, size: 8, font: fontMono, color: rgb(0,0,1) });


  // Metadata setting
  pdfDoc.setTitle('LEX_SENTINEL_WHITEPAPER');
  pdfDoc.setAuthor('Lex Sentinel Forensic Unit');
  pdfDoc.setSubject('Technical Architecture');

  return await pdfDoc.save();
};
