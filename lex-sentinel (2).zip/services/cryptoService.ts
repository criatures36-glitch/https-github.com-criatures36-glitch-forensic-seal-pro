
export const calculateHashes = async (file: File): Promise<{ sha256: string; sha512: string; arrayBuffer: ArrayBuffer }> => {
  // Verify Web Crypto support
  if (!window.crypto || !window.crypto.subtle) {
      throw new Error("Cryptographic API not available. Ensure you are using a modern browser in a Secure Context (HTTPS/Localhost).");
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = async (event) => {
      if (event.target?.result) {
        try {
          const arrayBuffer = event.target.result as ArrayBuffer;
          
          // Use Native Web Crypto API for high-performance hashing
          // Runs on a separate thread in most implementations, avoiding UI freeze
          const [hashBuffer256, hashBuffer512] = await Promise.all([
             window.crypto.subtle.digest('SHA-256', arrayBuffer),
             window.crypto.subtle.digest('SHA-512', arrayBuffer)
          ]);

          // Helper to convert buffer to Hex string
          const hashToHex = (buffer: ArrayBuffer) => {
             return Array.from(new Uint8Array(buffer))
                .map(b => b.toString(16).padStart(2, '0'))
                .join('');
          };

          resolve({ 
              sha256: hashToHex(hashBuffer256), 
              sha512: hashToHex(hashBuffer512), 
              arrayBuffer 
          });

        } catch (err: any) {
          reject(new Error("Cryptographic calculation failed: " + err.message));
        }
      } else {
        reject(new Error("File content is empty or unreadable."));
      }
    };
    
    reader.onerror = () => {
        // Capture specific FileReader error
        const err = reader.error;
        let details = "Unknown error";
        if (err) {
            details = `${err.name}: ${err.message}`;
        }
        
        if (err?.name === 'NotReadableError') {
             reject(new Error("File could not be read. It may be locked by another process or permissions are denied."));
        } else {
             reject(new Error(`File reading failed: ${details}`));
        }
    };
    
    reader.onabort = () => {
        reject(new Error("File reading was aborted."));
    }
    
    reader.readAsArrayBuffer(file);
  });
};
