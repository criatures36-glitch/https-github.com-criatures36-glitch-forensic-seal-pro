
import { ethers } from 'ethers';

// Define the window interface to include ethereum
declare global {
  interface Window {
    ethereum: any;
  }
}

export interface WalletConnection {
  address: string;
  chainId: number;
  provider: ethers.BrowserProvider;
  signer: ethers.Signer;
}

export interface Web3ErrorDetail {
  title: string;
  description: string;
  solution: string;
}

export const resolveWeb3Error = (error: any): Web3ErrorDetail => {
  let message = error?.message || "An unknown error occurred.";
  const code = error?.code || error?.info?.error?.code;

  // Ethers v6 errors often wrap the actual RPC error
  if (error?.info?.error?.message) {
      message = error.info.error.message;
  }

  // MetaMask/Provider User Rejected
  if (code === 4001 || code === 'ACTION_REJECTED' || message.includes("user rejected")) {
    return {
      title: "Authorization Declined",
      description: "The transaction or connection request was denied by the user.",
      solution: "Please approve the request in your wallet to proceed."
    };
  }

  // Pending Request
  if (code === -32002 || message.includes("already pending")) {
    return {
      title: "Request Pending",
      description: "A wallet prompt is already open and waiting for your input.",
      solution: "Check your wallet extension (e.g., MetaMask) popup window. It may be behind other windows."
    };
  }
  
  // Insufficient Funds
  if (code === 'INSUFFICIENT_FUNDS' || message.includes("insufficient funds")) {
    return {
      title: "Insufficient Balance",
      description: "You do not have enough native tokens (ETH/MATIC) to cover gas fees.",
      solution: "Top up your wallet with the network's native currency."
    };
  }

  // Network/RPC Errors
  if (code === 'NETWORK_ERROR' || message.includes("network")) {
    return {
      title: "Network Connection Issue",
      description: "Could not communicate with the blockchain node.",
      solution: "Check your internet connection. Try switching networks in your wallet and then switching back."
    };
  }
  
  // Nonce issues
  if (message.includes("nonce")) {
      return {
          title: "Transaction Sync Error",
          description: "Your wallet's transaction count (nonce) is out of sync with the network.",
          solution: "Reset your account in MetaMask settings (Settings > Advanced > Clear Activity Tab Data)."
      };
  }

  // Wallet missing
  if (message.includes("MetaMask") || message.includes("wallet")) {
      return {
          title: "Wallet Not Detected",
          description: "A Web3-compatible wallet is required to sign transactions.",
          solution: "Please install MetaMask or a compatible browser extension."
      };
  }

  // Fallback
  return {
    title: "System Error",
    description: message.length > 120 ? `${message.substring(0, 120)}...` : message,
    solution: "Please refresh the page or try reconnecting your wallet."
  };
};

export const connectWallet = async (): Promise<WalletConnection> => {
  // 1. Check if Window exists
  if (typeof window === 'undefined') {
    throw new Error("Window object not found.");
  }
  
  // 2. CHECK FOR WEB3 PROVIDER - STRICT MODE (No Simulation)
  if (!window.ethereum) {
    throw new Error("MetaMask (or compatible Web3 wallet) is not installed. Operation aborted to ensure security.");
  }

  try {
    // 3. Initialize Real Provider
    // "any" network allows the provider to detect the network automatically even if it changes
    const provider = new ethers.BrowserProvider(window.ethereum, "any");

    // 4. Request Access to Accounts
    const accounts = await provider.send("eth_requestAccounts", []);

    if (!accounts || accounts.length === 0) {
      throw new Error("No accounts authorized. Please connect your wallet.");
    }

    // 5. Get the Signer and Network details
    const signer = await provider.getSigner();
    const address = await signer.getAddress();
    const network = await provider.getNetwork();

    // Ensure we handle BigInt chainIds from ethers v6
    const chainId = Number(network.chainId);

    return {
      address,
      chainId,
      provider,
      signer
    };

  } catch (error: any) {
    console.error("Wallet Connection Error:", error);
    throw error;
  }
};

export const mintEvidenceNFT = async (hash: string, signer: ethers.Signer) => {
  if (!signer) {
    throw new Error("Wallet not connected. Cannot sign transaction.");
  }

  try {
    const address = await signer.getAddress();
    const timestamp = new Date().toISOString();
    
    // For this forensic tool, we create a Proof of Existence by sending a transaction
    // to the user's own address with the hash and metadata embedded in the "data" field.
    // This writes the evidence permanently to the blockchain history.
    
    const evidencePayload = {
        platform: "LEX SENTINEL",
        type: "FORENSIC_EVIDENCE",
        hash: hash,
        timestamp: timestamp,
        certifier: address
    };
    
    // Convert payload to Hex string for Ethereum data field
    // Using ethers v6 utilities
    const hexData = ethers.hexlify(ethers.toUtf8Bytes(JSON.stringify(evidencePayload)));
    
    // Send transaction (Self-transfer with data)
    const tx = await signer.sendTransaction({
        to: address, 
        value: 0,
        data: hexData
    });

    // We return the hash immediately. In a full production app, we would wait for 1 confirmation.
    // await tx.wait(1);
    
    return {
        txHash: tx.hash
    };

  } catch (error: any) {
    console.error("Minting Error:", error);
    // Rethrow to be handled by resolveWeb3Error in UI
    throw error;
  }
};
