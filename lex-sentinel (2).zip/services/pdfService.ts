
import { PDFDocument, rgb, StandardFonts, degrees, grayscale, PDFFont, PDFPage } from 'pdf-lib';
import QRCode from 'qrcode';
import { ForensicData, TradingReportData } from '../types';

// Constants for layout
const GOLD_COLOR = rgb(0.83, 0.68, 0.21); // #D4AF37
const RED_COLOR = rgb(0.53, 0, 0); // #880000
const DARK_COLOR = rgb(0.1, 0.1, 0.1);

/**
 * Helper to write multi-line text
 */
const drawTextLines = (
  page: PDFPage, 
  text: string, 
  x: number, 
  y: number, 
  font: PDFFont, 
  size: number, 
  maxWidth: number, 
  color: any = DARK_COLOR
) => {
  const words = text.split(' ');
  let line = '';
  let currentY = y;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const testWidth = font.widthOfTextAtSize(testLine, size);
    if (testWidth > maxWidth && n > 0) {
      page.drawText(line, { x, y: currentY, size, font, color });
      line = words[n] + ' ';
      currentY -= (size + 4);
    } else {
      line = testLine;
    }
  }
  page.drawText(line, { x, y: currentY, size, font, color });
  return currentY - (size + 10); // Return next Y position
};

/**
 * Draws a circular "Rubber Stamp" effect on the PDF
 */
const drawRubberStamp = (page: any, font: any, x: number, y: number) => {
  const size = 60;
  
  // Outer Circle
  page.drawCircle({
    x: x + (size/2),
    y: y + (size/2),
    size: size,
    borderWidth: 2,
    borderColor: RED_COLOR,
    opacity: 0.6,
  });

  // Inner Circle
  page.drawCircle({
    x: x + (size/2),
    y: y + (size/2),
    size: size - 4,
    borderWidth: 1,
    borderColor: RED_COLOR,
    opacity: 0.6,
  });

  // Center Text
  page.drawText('CERTIFIED', {
    x: x + 12,
    y: y + 26,
    size: 10,
    font: font,
    color: RED_COLOR,
    opacity: 0.8,
    rotate: degrees(15),
  });

  page.drawText('EVIDENCE', {
    x: x + 16,
    y: y + 16,
    size: 8,
    font: font,
    color: RED_COLOR,
    opacity: 0.8,
    rotate: degrees(15),
  });
};

/**
 * Applies a "Compulsado" (Certified Copy) style to the uploaded PDF.
 * Adds a cryptographic sidebar and a digital stamp.
 */
export const stampPdf = async (
  data: ForensicData, 
  signature: string | null
): Promise<Uint8Array> => {
  try {
    const pdfDoc = await PDFDocument.load(data.originalBuffer);
    const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    const courier = await pdfDoc.embedFont(StandardFonts.Courier);
    
    // Generate Verification QR
    const verificationUrl = `https://lex-sentinel.io/verify/${data.hashSHA256}`;
    const qrDataUrl = await QRCode.toDataURL(verificationUrl, { 
        color: { dark: '#000000', light: '#00000000' }, // Transparent bg
        margin: 0
    });
    const qrImageBytes = await fetch(qrDataUrl).then(res => res.arrayBuffer());
    const qrImage = await pdfDoc.embedPng(qrImageBytes);

    const pages = pdfDoc.getPages();
    
    // Apply certification mark to ALL pages
    pages.forEach((page, index) => {
      const { width, height } = page.getSize();
      
      // 1. Draw Cryptographic Side-Bar (Left Margin)
      // This is common in European digital signatures ("Cinta lateral")
      const barWidth = 25;
      page.drawRectangle({
        x: 0,
        y: 0,
        width: barWidth,
        height: height,
        color: GOLD_COLOR,
        opacity: 0.15,
      });

      // Vertical Text in Sidebar
      page.drawText(`LEX SENTINEL FORENSIC CERTIFICATION // HASH: ${data.hashSHA256.substring(0, 20)}... // PAGE ${index + 1} OF ${pages.length}`, {
        x: 8,
        y: 50,
        size: 6,
        font: courier,
        color: DARK_COLOR,
        rotate: degrees(90),
      });

      // 2. Add Top Header Seal (Only on first page)
      if (index === 0) {
        // Strip Background
        page.drawRectangle({
          x: 0,
          y: height - 40,
          width: width,
          height: 40,
          color: rgb(0.98, 0.98, 0.98),
          borderColor: GOLD_COLOR,
          borderWidth: 1,
        });

        // Lex Sentinel Logo Text
        page.drawText('LEX SENTINEL // FORENSIC UNIT', {
          x: 40,
          y: height - 25,
          size: 10,
          font: helveticaBold,
          color: DARK_COLOR,
        });

        // Timestamp
        page.drawText(`TSA: ${data.timestamp}`, {
          x: 40,
          y: height - 35,
          size: 7,
          font: courier,
          color: rgb(0.4, 0.4, 0.4),
        });

        // 3. Draw the "Rubber Stamp" Visual
        // Placed bottom right usually
        drawRubberStamp(page, helveticaBold, width - 80, 50);

        // 4. Digital Signature Footer
        if (signature) {
             page.drawText(`DIGITALLY SIGNED BY: ${signature}`, {
                x: 35,
                y: 10,
                size: 6,
                font: courier,
                color: RED_COLOR,
             });
        }
      } else {
        // On subsequent pages, add a small background for the QR code to ensure readability
        page.drawRectangle({
            x: width - 45,
            y: height - 38,
            width: 35,
            height: 35,
            color: rgb(1, 1, 1),
            opacity: 0.8
        });
      }

      // Embed QR Code on EVERY page (Top Right)
      page.drawImage(qrImage, {
        x: width - 45,
        y: height - 38,
        width: 35,
        height: 35,
      });
    });

    // Set Metadata
    pdfDoc.setTitle(`CERTIFIED_EVIDENCE_${data.fileName}`);
    pdfDoc.setAuthor('LEX SENTINEL FORENSIC UNIT');
    pdfDoc.setSubject(`SHA256: ${data.hashSHA256}`);
    pdfDoc.setProducer('Lex Sentinel Blockchain Notary Engine');

    return await pdfDoc.save();
  } catch (error) {
    console.error("PDF Stamp Error", error);
    throw new Error("Could not stamp PDF. Ensure the file is a valid PDF and not encrypted.");
  }
};

/**
 * Generates a generic "Perito Informático" style Audit Report.
 */
export const generateAuditReport = async (data: ForensicData, txHash: string | null): Promise<Uint8Array> => {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595.28, 841.89]); // A4
  const { width, height } = page.getSize();
  
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontMono = await pdfDoc.embedFont(StandardFonts.Courier);

  // Generate Verification QR for the Report
  const verificationUrl = `https://lex-sentinel.io/verify/${data.hashSHA256}`;
  const qrDataUrl = await QRCode.toDataURL(verificationUrl, { 
      color: { dark: '#000000', light: '#00000000' }, // Transparent bg
      margin: 0
  });
  const qrImageBytes = await fetch(qrDataUrl).then(res => res.arrayBuffer());
  const qrImage = await pdfDoc.embedPng(qrImageBytes);

  // --- HEADER ---
  page.drawRectangle({ x: 0, y: height - 100, width, height: 100, color: DARK_COLOR });
  
  page.drawText('LEX SENTINEL', {
    x: 50,
    y: height - 50,
    size: 28,
    font: fontBold,
    color: GOLD_COLOR,
  });
  
  page.drawText('CERTIFICADO DE AUDITORÍA FORENSE / CERTIFICATE OF FORENSIC AUDIT', {
    x: 50,
    y: height - 70,
    size: 9,
    font: fontRegular,
    color: rgb(0.8, 0.8, 0.8),
  });

  // Add QR to Header
  page.drawImage(qrImage, {
      x: width - 110,
      y: height - 90,
      width: 80,
      height: 80,
  });

  // --- CONTENT ---
  let y = height - 140;
  const leftCol = 50;
  const rightCol = 200;

  const drawLabel = (text: string) => {
    page.drawText(text, { x: leftCol, y, size: 9, font: fontBold, color: rgb(0.4, 0.4, 0.4) });
  };

  const drawValue = (text: string, isMono = true, color = DARK_COLOR) => {
    const maxLength = 65;
    if (text.length > maxLength) {
        const line1 = text.substring(0, maxLength);
        const line2 = text.substring(maxLength);
        page.drawText(line1, { x: rightCol, y, size: 9, font: isMono ? fontMono : fontRegular, color });
        y -= 12;
        page.drawText(line2, { x: rightCol, y, size: 9, font: isMono ? fontMono : fontRegular, color });
    } else {
        page.drawText(text, { x: rightCol, y, size: 9, font: isMono ? fontMono : fontRegular, color });
    }
  };

  const drawSection = (title: string) => {
    y -= 20;
    page.drawText(title, { x: leftCol, y, size: 12, font: fontBold, color: DARK_COLOR });
    page.drawLine({ start: { x: leftCol, y: y - 5 }, end: { x: width - 50, y: y - 5 }, thickness: 1, color: GOLD_COLOR });
    y -= 25;
  };

  // 1. EVIDENCE IDENTIFICATION
  drawSection('1. IDENTIFICACIÓN DE EVIDENCIA / EVIDENCE ID');
  
  drawLabel('FILE NAME:'); drawValue(data.fileName, false); y -= 15;
  drawLabel('FILE SIZE:'); drawValue(`${data.fileSize} bytes`, true); y -= 15;
  drawLabel('MIME TYPE:'); drawValue(data.fileType, true); y -= 15;
  drawLabel('LAST MODIFIED:'); drawValue(new Date(data.lastModified).toUTCString(), true); y -= 15;

  // 2. CRYPTOGRAPHIC FINGERPRINTS
  drawSection('2. HUELLA DIGITAL CRIPTOGRÁFICA / HASHES');
  
  drawLabel('ALGORITHM:'); drawValue('SHA-256 (NIST Standard)', false); y -= 15;
  drawLabel('DIGEST:'); drawValue(data.hashSHA256); y -= 25;
  
  drawLabel('ALGORITHM:'); drawValue('SHA-512 (High Security)', false); y -= 15;
  drawLabel('DIGEST:'); drawValue(data.hashSHA512); y -= 25;

  // 3. BLOCKCHAIN ANCHOR
  drawSection('3. REGISTRO INMUTABLE / BLOCKCHAIN ANCHOR');
  
  if (txHash) {
    drawLabel('STATUS:'); drawValue('CONFIRMED / CONFIRMADO', false, rgb(0, 0.5, 0)); y -= 15;
    drawLabel('NETWORK:'); drawValue('ETHEREUM VIRTUAL MACHINE (EVM)', false); y -= 15;
    drawLabel('TX HASH:'); drawValue(txHash); y -= 15;
    drawLabel('TIMESTAMP:'); drawValue(data.timestamp, true); y -= 15;
  } else {
    drawLabel('STATUS:'); drawValue('NOT ANCHORED / NO REGISTRADO', false, RED_COLOR); y -= 15;
  }

  // 4. LEGAL DISCLAIMER
  y -= 20;
  page.drawRectangle({ x: 40, y: y - 100, width: width - 80, height: 100, color: rgb(0.95, 0.95, 0.95), borderColor: rgb(0.9, 0.9, 0.9), borderWidth: 1 });
  
  y -= 15;
  const disclaimerTitle = "DECLARACIÓN DE VALIDEZ JURÍDICA / LEGAL STATEMENT";
  page.drawText(disclaimerTitle, { x: 50, y, size: 8, font: fontBold, color: DARK_COLOR });
  y -= 15;

  const disclaimerText = [
    "This document certifies that the cryptographic integrity of the digital evidence has been preserved.",
    "The hash calculation was performed client-side, ensuring user privacy (GDPR compliant).",
    "If the Transaction Hash is present, this document serves as a 'Proof of Existence' on a decentralized",
    "public ledger, providing mathematical proof that the document existed at the specified time.",
    "Compliant with eIDAS (EU No 910/2014) regarding electronic timestamps and data integrity.",
    "Cumple con normativa de firma electrónica y sellado de tiempo para evidencias digitales."
  ];

  disclaimerText.forEach(line => {
    page.drawText(line, { x: 50, y, size: 7, font: fontRegular, color: rgb(0.3, 0.3, 0.3) });
    y -= 10;
  });

  // --- FOOTER ---
  const bottomY = 40;
  page.drawLine({ start: { x: 50, y: bottomY + 20 }, end: { x: width - 50, y: bottomY + 20 }, thickness: 0.5, color: rgb(0.8, 0.8, 0.8) });
  
  page.drawText(`GENERATED BY LEX SENTINEL | ID: ${data.hashSHA256.substring(0,16)}`, {
    x: 50,
    y: bottomY,
    size: 6,
    font: fontMono,
    color: rgb(0.6, 0.6, 0.6)
  });

  return await pdfDoc.save();
};

/**
 * Plantilla 1: INFORME DE AUDITORÍA FORENSE SOBRE OPERACIONES DE TRADING EN ASTER DEX
 * Now uses REAL input data, no simulation.
 */
export const generateJudicialReport = async (data: ForensicData, walletAddress: string, reportData: TradingReportData): Promise<Uint8Array> => {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595.28, 841.89]);
  const { width, height } = page.getSize();
  
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontMono = await pdfDoc.embedFont(StandardFonts.Courier);

  const tData = reportData;
  const safeWallet = walletAddress || "0xUNKNOWN_WALLET_ADDRESS";
  const dateStr = new Date().toLocaleDateString();

  let y = height - 50;
  const margin = 50;
  const maxWidth = width - (margin * 2);

  // Title
  y = drawTextLines(page, "INFORME DE AUDITORÍA FORENSE SOBRE OPERACIONES DE TRADING EN ASTER DEX", margin, y, fontBold, 16, maxWidth, DARK_COLOR);
  y -= 10;
  
  // DATOS DEL CASO
  y = drawTextLines(page, "DATOS DEL CASO", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  y = drawTextLines(page, `Peritado por: LEX SENTINEL AI FORENSICS`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Cuenta afectada: Wallet ${safeWallet} – UID ${tData.uid}`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Plataforma: ${tData.platform} – Producto: Futuros`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Periodo analizado: ${tData.periodStart} a ${tData.periodEnd}`, margin, y, fontRegular, 10, maxWidth);
  y -= 10;

  // OBJETO
  y = drawTextLines(page, "OBJETO DEL INFORME", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  y = drawTextLines(page, "El presente informe tiene por objeto analizar las operaciones ejecutadas en la cuenta indicada, detectar fallos sistémicos de contabilidad (órdenes FILLED frontales a registros FAILED, comisiones cobradas sin servicio y ráfagas de cobros duplicados) y cuantificar el daño económico sufrido por el titular.", margin, y, fontRegular, 10, maxWidth);
  y -= 10;

  // METODOLOGÍA
  y = drawTextLines(page, "METODOLOGÍA FORENSE", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  y = drawTextLines(page, "Fuentes de datos: CSV oficiales de Order History y Transaction History, registros de balance, capturas de pantalla certificadas y anclajes en blockchain. Procedimiento: conciliación entre órdenes FILLED y transacciones registradas, detección de estados FAILED con fee.", margin, y, fontRegular, 10, maxWidth);
  y -= 10;

  // HALLAZGOS
  y = drawTextLines(page, "HALLAZGOS TÉCNICOS PRINCIPALES", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  
  y = drawTextLines(page, "4.1 Órdenes FILLED con estado FAILED y comisión cobrada", margin, y, fontBold, 10, maxWidth);
  y = drawTextLines(page, `Número de casos detectados: ${tData.nFilledFailed}`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Importe total de comisiones asociadas: ${tData.feesFilledFailed} USDT.`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Importe estimado de PnL no abonado: ${tData.pnlNoAbonado} USDT.`, margin, y, fontRegular, 10, maxWidth);
  y -= 5;

  y = drawTextLines(page, "4.2 Operaciones FAILED con comisión sin servicio", margin, y, fontBold, 10, maxWidth);
  y = drawTextLines(page, `Número de casos: ${tData.nFailedFee}`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Comisiones cobradas sin contraprestación: ${tData.feesFailed} USDT.`, margin, y, fontRegular, 10, maxWidth);
  y -= 5;

  y = drawTextLines(page, "4.3 Ataque algorítmico de cobros duplicados", margin, y, fontBold, 10, maxWidth);
  y = drawTextLines(page, `Número de ráfagas detectadas: ${tData.nRafagas}.`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Comisiones cobradas en exceso: ${tData.feesDobles} USDT.`, margin, y, fontRegular, 10, maxWidth);
  y -= 5;

  y = drawTextLines(page, "4.4 Bloqueos técnicos y errores de plataforma", margin, y, fontBold, 10, maxWidth);
  y = drawTextLines(page, `Eventos documentados: ${tData.errors401} errores 401, ${tData.errorsSys} “system abnormality”. Impacto: imposibilidad de cerrar o gestionar posiciones.`, margin, y, fontRegular, 10, maxWidth);
  y -= 10;

  // CUANTIFICACIÓN
  y = drawTextLines(page, "CUANTIFICACIÓN DEL DAÑO", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  y = drawTextLines(page, `Pérdidas inducidas por fallos de ejecución: ${tData.perdidasInducidas} USDT.`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Beneficios no abonados (lucro cesante): ${tData.pnlNoAbonado} USDT.`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Comisiones cobradas indebidamente: ${tData.feesFailed} USDT.`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `TOTAL RECLAMADO: ${tData.totalDanos} USDT.`, margin, y, fontBold, 10, maxWidth, RED_COLOR);
  y -= 10;

  // CONCLUSIONES
  y = drawTextLines(page, "CONCLUSIONES Y PETICIONES", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  y = drawTextLines(page, `Se concluye que ASTER DEX debe proceder a restituir al titular el total de ${tData.totalDanos} USDT. Este informe se emite a efectos de su presentación ante los órganos judiciales.`, margin, y, fontRegular, 10, maxWidth);

  // Footer
  page.drawRectangle({ x: 0, y: 0, width: width, height: 40, color: DARK_COLOR });
  page.drawText(`LEX SENTINEL | HASH: ${data.hashSHA256.substring(0,16)}`, { x: margin, y: 15, size: 8, font: fontMono, color: GOLD_COLOR });

  return await pdfDoc.save();
};

/**
 * Plantilla 2: INFORME DE ACUERDO EXTRAJUDICIAL
 * Now uses REAL input data, no simulation.
 */
export const generateSettlementReport = async (data: ForensicData, walletAddress: string, reportData: TradingReportData): Promise<Uint8Array> => {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595.28, 841.89]);
  const { width, height } = page.getSize();
  
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontMono = await pdfDoc.embedFont(StandardFonts.Courier);

  const tData = reportData;
  const safeWallet = walletAddress || "0xUNKNOWN";
  const dateStr = new Date().toLocaleDateString();

  let y = height - 50;
  const margin = 50;
  const maxWidth = width - (margin * 2);

  // Title
  y = drawTextLines(page, "INFORME RESUMIDO DE AUDITORÍA FORENSE Y PROPUESTA DE ACUERDO EXTRAJUDICIAL", margin, y, fontBold, 14, maxWidth, DARK_COLOR);
  y -= 10;

  // IDENTIFICACIÓN
  y = drawTextLines(page, "IDENTIFICACIÓN", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  y = drawTextLines(page, `Titular: Usuario Verificado`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Wallet / UID: ${safeWallet} / ${tData.uid}`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `Plataforma: ${tData.platform} – Futuros`, margin, y, fontRegular, 10, maxWidth);
  y -= 10;

  // RESUMEN EJECUTIVO
  y = drawTextLines(page, "RESUMEN EJECUTIVO", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  y = drawTextLines(page, `Tras auditar operaciones realizadas entre ${tData.periodStart} y ${tData.periodEnd}, se han identificado fallos sistemáticos en la contabilidad de ASTER DEX. La suma de estos fallos genera un daño económico total de ${tData.totalDanos} USDT.`, margin, y, fontRegular, 10, maxWidth);
  y -= 10;

  // INCIDENCIAS
  y = drawTextLines(page, "PRINCIPALES INCIDENCIAS DETECTADAS", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  y = drawTextLines(page, `• Órdenes FILLED registradas como FAILED con comisión cobrada (n=${tData.nFilledFailed}, importe=${tData.feesFilledFailed} USDT).`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `• Operaciones FAILED con comisión cargada (n=${tData.nFailedFee}, importe=${tData.feesFailed} USDT).`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `• Ráfagas de cobros duplicados (${tData.nRafagas} ráfagas, ${tData.feesDobles} USDT).`, margin, y, fontRegular, 10, maxWidth);
  y -= 10;

  // CUANTÍA
  y = drawTextLines(page, "CUANTÍA RECLAMADA", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  y = drawTextLines(page, `TOTAL: ${tData.totalDanos} USDT.`, margin, y, fontBold, 14, maxWidth, RED_COLOR);
  y -= 10;

  // PROPUESTA
  y = drawTextLines(page, "PROPUESTA DE SOLUCIÓN", margin, y, fontBold, 12, maxWidth, GOLD_COLOR);
  y = drawTextLines(page, `Con el fin de evitar un conflicto público y la apertura de expedientes ante reguladores, se propone el siguiente acuerdo:`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `1. Pago íntegro de ${tData.totalDanos} USDT a la wallet ${safeWallet} en un plazo máximo de 48 horas.`, margin, y, fontRegular, 10, maxWidth);
  y = drawTextLines(page, `2. Opcionalmente, firma de un Acuerdo de Confidencialidad (NDA).`, margin, y, fontRegular, 10, maxWidth);
  y -= 10;

  // AVISO
  y = drawTextLines(page, "AVISO DE ESCALADA", margin, y, fontBold, 12, maxWidth, RED_COLOR);
  y = drawTextLines(page, `Transcurrido el plazo sin solución, el titular se reserva el derecho de escalar este expediente ante autoridades regulatorias.`, margin, y, fontRegular, 10, maxWidth);

  // Footer
  page.drawRectangle({ x: 0, y: 0, width: width, height: 40, color: DARK_COLOR });
  page.drawText(`LEX SENTINEL SETTLEMENT DOC | ${dateStr}`, { x: margin, y: 15, size: 8, font: fontMono, color: GOLD_COLOR });

  return await pdfDoc.save();
};
